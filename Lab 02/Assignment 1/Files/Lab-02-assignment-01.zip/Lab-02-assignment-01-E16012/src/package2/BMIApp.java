package package2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;

import package1.Person;

public class BMIApp {

	public static void main(String[] args) throws IOException {
		
		/*Reading from input text file*/
	
		BufferedReader br;
		
		ArrayList<Person> personList = new ArrayList<Person>();
		
		
		String[] lineArray = new String[3]; 
		String text_line = null;
		
		try {
			br = Files.newBufferedReader(Paths.get("src/input.txt"));
			
			text_line = br.readLine();
			
			while(text_line !=null) {
							
				lineArray = text_line.split(",");
				
				/*Save Name, Height and Weight of each person in Person object*/
				
				Person person = new Person();
				person.setName(lineArray[0].toString());
				person.setHeight(Double.parseDouble(lineArray[1]));
				person.setWeight(Double.parseDouble(lineArray[2]));
				person.setBMI();
				person.setStatus();
				
				/*Add Person object to personList*/
				personList.add(person);
				text_line = br.readLine();
				
			}
			br.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

		/*Output the details of people*/		

		for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {
			Person person2 = (Person) iterator.next();
			System.out.println(person2.toString());	
		}
	}

}

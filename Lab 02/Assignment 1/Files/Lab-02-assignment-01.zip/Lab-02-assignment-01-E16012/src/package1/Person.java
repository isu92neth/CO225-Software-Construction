package package1;

public class Person {
	private String name;
	private double height;
	private double weight;
	private double bmi;
	private String status;
	
	/*Method to return the Name*/
	public String getName() {
		return name;
	}
	
	/*Method to save the Name*/
	public void setName(String name) {
		this.name=name;
	}
	
	/*Method to return the Weight*/
	public double getweight() {
		return weight;
	}
	
	/*Method to save the Weight*/
	public void setWeight(double weight) {
		this.weight=weight;
	}
	
	/*Method to return the Height*/
	public double getHeight() {
		return height;
	}
	
	/*Method to save the Height*/
	public void setHeight(double height) {
		this.height=height;
	}
	
	/*Method to calculate BMI*/
	public void setBMI() {
		this.bmi = Math.round( weight/(height*height) *100.0)/100.0;
	}
	
	/*Method to choose status according to BMI*/
	public void setStatus() {
		if(bmi>25) {
			this.status="You are overweight";
		}
		else if(bmi>18.5){
			this.status="You are healthy";
		}
		else {
			this.status="Not healthy";
		}
	}
	@Override
	public String toString() {
		return "Person [Name: " + name + ", Height(m): " + height + ", Weight(kg): " + weight + ", BMI: " + bmi + ", Status: "
				+ status + "]";
	}
}

package package2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import package1.User;


public class ContactApp {
	public static void main(String[] args) throws IOException {
		
		/*Takes the User input*/
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter name :  ");
		String input=in.nextLine();
		
		/*Check for first or second name*/
		char nameId=input.charAt(0);
		/*Saves first or second name from the input*/
		String name=input.substring(2).toLowerCase();
		in.close();
		
		/*Check if input format is correct*/
		if(nameId!='F') {
			if(nameId!='L') {
				System.out.println("Wrong Input Format");
				System.out.println("Correct Input Format is F/L:Name");
				System.exit(0);
			}
		}
		

		BufferedReader br;
		
		ArrayList<User> userList = new ArrayList<User>();
		
		String[] lineArray = new String[3]; 
		String text_line = null;

		try {
			br = Files.newBufferedReader(Paths.get("src/contacts.txt"));
			
			text_line = br.readLine();
		
			
			while(text_line !=null) {
				
				
				lineArray = text_line.split(",");
				
				/*Saves first name, last name, contact number in user object*/
				
				User user = new User();
				user.setFirstName(lineArray[0].toString());
				user.setLastName(lineArray[1].toString());
				user.setPhoneNum(lineArray[2].toString());
				userList.add(user);
				text_line = br.readLine();
			}
			br.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		/*Check if first or last name exist in contacts list*/
		int count=0;
		for(User user2:userList) {
			if(nameId=='F' && name.equals(user2.getFirstName().toLowerCase())) {
				System.out.println(user2.toString());
				count+=1;
			}
			else if(nameId=='L' && name.equals(user2.getLastName().toLowerCase())) {
				System.out.println(user2.toString());
				count+=1;
			}
		}
		
		/*Check if there were no matching contacts*/
		if(count==0) {
			System.out.println("No such contact");
		}
	}

}

package package1;

public class User {
	private String firstName;
	private String lastName;
	private String phoneNum;
	
	/*Method to return First name*/
	public String getFirstName() {
		return firstName;
	}
	
	/*Method to save First name*/
	public void setFirstName(String firstName) {
		this.firstName=firstName;
	}
	
	/*Method to return Last name*/
	public String getLastName() {
		return lastName;
	}
	
	/*Method to save Last name*/
	public void setLastName(String lastName) {
		this.lastName=lastName;
	}
	
	/*Method to return Phone number*/
	public String getPhoneNum() {
		return phoneNum;
	}
	
	/*Method to save Phone number*/
	public void setPhoneNum(String phoneNum) {
		this.phoneNum=phoneNum;
	}
	@Override
	public String toString() {
		return "Contact Details [FirstName=" + firstName + ", LastName=" + lastName + ", Phone Number=" + phoneNum + "]";
	}
	
}

